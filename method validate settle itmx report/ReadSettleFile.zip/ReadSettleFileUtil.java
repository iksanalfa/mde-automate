package utils;

import java.io.BufferedReader;
import java.io.FileReader;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

public class ReadSettleFileUtil {

	public ReadSettleFileDto runProses(String relativePath, String fileName) {
		say("start try parsing text settle : ".concat(fileName));
		ReadSettleFileDto dto = new ReadSettleFileDto();

		String userDirectory = System.getProperty("user.dir");
//		String relativePath = "ReadSettleFile";
//		String fileName = "QRX_SETTLE_360004_000911_210728_ISS_1";
//		String fileName = "QRX_SETTLE_360004_000008_210728_ACQ_1";
		String finalPath = userDirectory.concat("\\").concat(relativePath).concat("\\").concat(fileName);

		BufferedReader br = null;
		String line = "";
		Integer lineNumber = 1;
		List<String> listResult = new ArrayList<String>();

		try {
			br = new BufferedReader(new FileReader(finalPath));
			while ((line = br.readLine()) != null) {
				//--start proses
				///say(line);
				///say(lineNumber);

				//pattern 1 line 3-7
				if (lineNumber >= 3 && lineNumber <= 7) {
					///say("-start pattern 1");
					listResult = readPattern1(lineNumber, line, listResult);
				}
				//pattern 2 line 11
				if (lineNumber == 11) {
					///say("-start pattern 2");
					listResult = readPattern2(lineNumber, line, listResult);
				}
				//pattern 3 line 13-22
				if (lineNumber >= 13 && lineNumber <= 22) {
					///say("-start pattern 3");
					listResult = readPattern3(lineNumber, line, listResult);
				}
				//pattern 3 line 35-36
				if (lineNumber >= 35 && lineNumber <= 36) {
					///say("-start pattern 3");
					listResult = readPattern3(lineNumber, line, listResult);
				}
				//pattern 3 line 39-50
				if (lineNumber >= 39 && lineNumber <= 50) {
					///say("-start pattern 3");
					listResult = readPattern3(lineNumber, line, listResult);
				}
				//pattern 3 line 53-64
				if (lineNumber >= 53 && lineNumber <= 64) {
					///say("-start pattern 3");
					listResult = readPattern3(lineNumber, line, listResult);
				}
				//--end
				lineNumber++;
	        }
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		///say(finalPath);
		//set dto dari list result
		setDto(dto, listResult, 0, listResult.size()-1);
		//print all dto field, kalau kosong dia string kosong, kalau ada null kemungkinan text settlenya berubah
		printDto(dto);

		say("---end try parsing text settle : ".concat(fileName));
		///---
		return dto;
	}

	private void say(Object tosay) {
		System.out.println(tosay);
	}

	private void printDto(Object clas1) {
		for (Field field : clas1.getClass().getDeclaredFields()) {
		    field.setAccessible(true);
		    String name = field.getName();
		    Object value = null;
			try {
				value = field.get(clas1);
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    System.out.printf("%s: %s%n", name, value);
		}
	}

	//setDto bergantung pada urutan list result dan field pada class dto
	private Object setDto(Object dto, List<String> indexResult, Integer indexStartSet, Integer indexEndSet) {
		Integer ifield = 0;
		Integer iindexR = 0;
		for (Field field : dto.getClass().getDeclaredFields()) {
		    field.setAccessible(true);
			try {
				if (ifield >= indexStartSet && ifield <= indexEndSet) {
					field.set(dto, indexResult.get(iindexR));
					iindexR++;
				}
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			ifield++;
		}
		return dto;
	}

	//pattern 3 line 13-22  //pattern 3 line 35-36  //pattern 3 line 39-50  //pattern 3 line 53-64
	private List<String> readPattern3(Integer lineNumber, String line, List<String> listResult) {
		Integer index1 = Integer.valueOf( line.indexOf(":") );
		String val1 = line.substring(index1+2).trim();
		listResult.add(val1);
		return listResult;
	}

	//pattern 2 line 11
	private List<String> readPattern2(Integer lineNumber, String line, List<String> listResult) {
		Integer[] indexVal = {0, 7, 16, 28, 37, 50, 59, 76, 96, 108, 120, 140, 149, 166, 175, 192, 209, 227, 245, 259, 300, 313};
		///say(indexVal.length); //index = length - 1
		for (Integer i=0 ; i <= indexVal.length-1 ; i++) {
			String val1 = "";
			if (i == indexVal.length-1) {
				val1 = line.substring(indexVal[i], line.length());
				listResult.add(val1.trim());
			} else {
				val1 = line.substring(indexVal[i], indexVal[i+1]);
				listResult.add(val1.trim());
			}
			///say(val1);
		}
		return listResult;
	}

	//pattern 1 line 3-7
	private List<String> readPattern1(Integer lineNumber, String line, List<String> listResult) {
		Integer index1 = Integer.valueOf( line.indexOf(":") );
		Integer index2 = Integer.valueOf( line.indexOf(":", index1+1 ) );
		String val1 = line.substring(index1+2, index1+20).trim();
		String val2 = line.substring(index2+2).trim();
		listResult.add(val1);
		listResult.add(val2);
		///say( line );
		///say( index1 );
		///say( index2 );
		///say( val1 );
		///say( val2 );
		return listResult;
	}

	//--------------------------------versi 2 by search string------------------------------------------

	public ReadSettleFileGrandTotalDto runProsesSearchString(String relativePath, String fileName) {
		say("start try v2 parsing text settle : ".concat(fileName));
		ReadSettleFileGrandTotalDto dto = new ReadSettleFileGrandTotalDto();

		String userDirectory = System.getProperty("user.dir");
//		String relativePath = "ReadSettleFile";
//		String fileName = "QRX_SETTLE_360004_000911_210728_ISS_1";
//		String fileName = "QRX_SETTLE_360004_000008_210728_ACQ_1";
		String finalPath = userDirectory.concat("\\").concat(relativePath).concat("\\").concat(fileName);

		BufferedReader br = null;
		String line = "";
		Integer lineNumber = 1;
		List<String> listResult = new ArrayList<String>();

		try {
			br = new BufferedReader(new FileReader(finalPath));
			while ((line = br.readLine()) != null) {
				//--start proses
				///say(line);
				///say(lineNumber);

				//search grand total
				searchGrandTotal(lineNumber, line, listResult);

				//--end
				lineNumber++;
	        }
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		///say(finalPath);
		//set dto dari list result
		setDto(dto, listResult, 0, listResult.size()-1);
		//print all dto field, kalau kosong dia string kosong, kalau ada null kemungkinan text settlenya berubah
		printDto(dto);

		say("---end try v2 parsing text settle : ".concat(fileName));
		///---
		return dto;
	}

	//search 1 grand total
	private void searchGrandTotal(Integer lineNumber, String line, List<String> listResult) {

		String[] grandTotal = {"GRAND TOTAL TRANSAKSI DISPUTE","GRAND TOTAL NET DISPUTE AMOUNT (v)",
								"GRAND TOTAL PAYMENT CREDIT", "GRAND TOTAL AMOUNT PAYMENT CREDIT (w)",
								"GRAND TOTAL AMOUNT PAYMENT CREDIT FOREIGN (t)", "GRAND TOTAL INTERCHANGE FEE PAYMENT CREDIT (x)",
								"GRAND TOTAL REFUND", "GRAND TOTAL AMOUNT REFUND (y)",
								"GRAND TOTAL AMOUNT REFUND FOREIGN (u)", "GRAND TOTAL INTERCHANGE FEE REFUND (z)",
								"GRAND TOTAL SETTLEMENT AMOUNT (v+w+x+y+z)", "GRAND TOTAL SETTLEMENT AMOUNT FOREIGN (t+u)"};

		for (Integer i=0 ; i <= grandTotal.length-1 ; i++) {
			if (line.contains(grandTotal[i])) {
				readPattern3(lineNumber, line, listResult);
				break;
			}
		}

	}


}
