package utils;

import lombok.Data;

@Data
public class ReadSettleFileGrandTotalDto {
	//urutan field jangan diubah
	//---index0
	private String grandTotalTransaksiDispute;
	private String grandTotalNetDisputeAmountV;
	private String grandTotalPaymentCredit;
	private String grandTotalAmountPaymentCreditW;
	private String grandTotalAmountPaymentCreditForeignT;
	private String grandTotalInterchangeFeePaymentCreditX;
	private String grandTotalRefund;
	private String grandTotalAmountRefundY;
	private String grandTotalAmountRefundForeignU;
	private String grandTotalInterchangeFeeRefundZ;
	private String grandTotalSettlementAmountVWXYZ;
	private String grandTotalSettlementAmountForeignTU;

}
