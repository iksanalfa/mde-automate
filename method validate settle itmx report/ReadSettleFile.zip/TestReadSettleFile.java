package runners;

import utils.ReadSettleFileUtil;

public class TestReadSettleFile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ReadSettleFileUtil s = new ReadSettleFileUtil();
//		s.runProses("ReadSettleFile", "QRX_SETTLE_360004_000008_210728_ACQ_1");
//		s.runProses("ReadSettleFile", "QRX_SETTLE_360004_000911_210728_ISS_1");
//		s.runProses("ReadSettleFile", "QRX_SETTLE_360004_458001_210728_ACQ_1");
//		s.runProses("ReadSettleFile", "QRX_SETTLE_360004_458001_210728_ISS_1");
		s.runProsesSearchString("ReadSettleFile", "QRX_SETTLE_360004_000008_210728_ACQ_1");
		s.runProsesSearchString("ReadSettleFile", "QRX_SETTLE_360004_000008_210728_ACQ_edited");
//		s.runProsesSearchString("ReadSettleFile", "QRX_SETTLE_360004_000911_210728_ISS_1");
//		s.runProsesSearchString("ReadSettleFile", "QRX_SETTLE_360004_458001_210728_ACQ_1");
//		s.runProsesSearchString("ReadSettleFile", "QRX_SETTLE_360004_458001_210728_ISS_1");
	}

}
