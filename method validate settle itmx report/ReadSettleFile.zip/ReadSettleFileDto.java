package utils;

import lombok.Data;

@Data
public class ReadSettleFileDto {
	//urutan field jangan diubah
	//---index0
	private String noReport;
	private String frekwensi;
	private String layanan;
	private String tanggalReport;
	private String prinsipal;
	private String tanggalSettlement;
	private String kodeNegara;
	private String waktuReport;
	private String posisi;
	private String halaman;
	///---index11
	private String no;
	private String trxCode;
	private String tanggalTrx;
	private String jamTrx;
	private String refNo;
	private String traceNo;
	private String terminalID;
	private String merchantPAN;
	private String acquirer;
	private String issuer;
	//---index21
	private String customerPAN;
	private String trxCurr;
	private String trxAmt;
	private String chbCurr;
	private String chbAmt;
	private String fXRate;
	private String merchantCategory;
	private String merchantCriteria;
	private String responseCode;
	private String merchantNameLocation;
	//--index31
	private String convenienceFee;
	private String interchangeFee;
	private String subTotalPaymentCredit;
	private String subTotalAmountPaymentCreditA;
	private String subTotalAmountPaymentCreditForeignEpage;
	private String subTotalInterchangeFeePaymentCreditB;
	private String subTotalRefundPage;
	private String subTotalAmountRefundCpage;
	private String subTotalAmountRefundForeignFpage;
	private String subTotalInterchangeFeeRefundDpage;
	//---index41
	private String subTotalSettlementAmountABCDpage;
	private String subTotalSettlementAmountForeignEFpage;
	private String subTotalTransaksiDisputePage;
	private String subTotalnetDisputeAmountPage;
	private String totalTransaksiDisputeCountry;
	private String totalNetDisputeAmountKcountry;
	private String totalPaymentCreditCountry;
	private String totalAmountPaymentCreditLcountry;
	private String totalAmountPaymentCreditForeignPcountry;
	private String totalInterchangeFeePaymentCreditMcountry;
	//---index51
	private String totalRefundCountry;
	private String totalAmountRefundNcountry;
	private String totalAmountRefundForeignQcountry;
	private String totalInterchangeFeeRefundZeroCountry;
	private String totalSettlementAmountKLMNzeroCountry;
	private String totalSettlementAmountForeignPQcountry;
	private String grandTotalTransaksiDispute;
	private String grandTotalNetDisputeAmountV;
	private String grandTotalPaymentCredit;
	private String grandTotalAmountPaymentCreditW;
	//---index61
	private String grandTotalAmountPaymentCreditForeignT;
	private String grandTotalInterchangeFeePaymentCreditX;
	private String grandTotalRefund;
	private String grandTotalAmountRefundY;
	private String grandTotalAmountRefundForeignU;
	private String grandTotalInterchangeFeeRefundZ;
	private String grandTotalSettlementAmountVWXYZ;
	private String grandTotalSettlementAmountForeignTU;

}
