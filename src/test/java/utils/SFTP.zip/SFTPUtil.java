package utils;

import java.util.UUID;
import java.util.Vector;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

public class SFTPUtil {
	
	public void listDirectory(String cmd) {
		
		say("SFTP start");
	
		String username = "test2";
	    String host = "127.0.0.1";
	    Integer port = 22;
	    String pass = "test2";
	    String khfile = "/zmde-auto/SFTP/known_hosts";
	    String identityfile = "/zmde-auto/SFTP/key.pem";
	    String dir = "/";
	    UUID randUUID = UUID.randomUUID();
	    String diff = randUUID.toString().substring(0, 8);
	
	    JSch jsch = null;
	    Session session = null;
	    Channel channel = null;    
	    ChannelSftp c = null;
	    
	    try {
	        jsch = new JSch();
	        session = jsch.getSession(username, host, port);
	        session.setPassword(pass);
	        jsch.setKnownHosts(khfile);
	        jsch.addIdentity(identityfile);
	        session.connect();
	        
	        //check server key
	        /*HostKey hk=session.getHostKey();
	    	System.out.println("HostKey: "+
	    			   hk.getHost()+" "+
	    			   hk.getType()+" "+
	    			   hk.getFingerPrint(jsch));
	    	*/
	        
	        channel = session.openChannel("sftp");
	        channel.connect();
	        c = (ChannelSftp) channel;
	        
	        //List Dir
	        if (cmd.equalsIgnoreCase("testlistdir")) {
	        	say("-list directory");
		        c.cd(dir);
	            Vector<?> filelist = c.ls("*");
	            for(int i=0; i<filelist.size();i++){
	            	LsEntry entry = (LsEntry) filelist.get(i);
	                System.out.println(entry.getFilename());
	                ///System.out.println(filelist.get(i).toString());
	            }
	        }
            //---End List Dir
	        
	        //Upload file
	        if (cmd.equalsIgnoreCase("testupload")) {
	        	say("-upload");
	        	String localFile = "/SFTP/testfiletoupload.txt";
	            String remoteDir = "/";	         
	            c.put(localFile, remoteDir + diff +"-testfiletoupload.txt");
	            c.exit();
	        }
	        //---End Upload file
	        
	        //Download file
	        if (cmd.equalsIgnoreCase("testdownload")) {
	        	say("-download");
	        	String remoteFile = "/testdownload.txt";
	            String localDir = "/SFTP/";	         
	            c.get(remoteFile, localDir + diff +"-testdownload.txt");
	            c.exit();
	        }
	        //---End Download file

	
	    } catch (Exception e) { 	e.printStackTrace();	}
	
	    
	    c.disconnect();
	    session.disconnect();
	    
	    say("---SFTP end");
    
	}
	
	private void say(Object tosay) {
		System.out.println(tosay);
	}
    
}
